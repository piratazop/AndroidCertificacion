package com.example.android.Model.Remoto.FromInternet

data class ListaInternet (

    val id: Int,
    val artista: String,
    val fecha: String,
    val lugar: String,
    val ciudad: String,
    val imagen: String,
    val entradas: String


)